import styled from 'styled-components';

const PokemonComponent = styled.div`
  margin-top: 30px;
  background: red;
  padding: 30px;
  h4 {
    margin: 0;
  }
  .display {
    background: white;
    padding: 10px;
  }
  .moves {
    
  }
`;

export default PokemonComponent;
